/**
 * ServicioPractica1_Service.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.example.www.servicioPractica1;

public interface ServicioPractica1_Service extends javax.xml.rpc.Service {
    public java.lang.String getservicioPractica1SOAPAddress();

    public org.example.www.servicioPractica1.ServicioPractica1_PortType getservicioPractica1SOAP() throws javax.xml.rpc.ServiceException;

    public org.example.www.servicioPractica1.ServicioPractica1_PortType getservicioPractica1SOAP(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
